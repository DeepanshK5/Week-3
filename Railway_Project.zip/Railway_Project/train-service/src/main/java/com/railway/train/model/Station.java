package com.railway.train.model;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class Station {


    @NotNull(message = "Station ID is required")
    private Long id;

    @NotBlank(message = "Station name is required")
    private String stationName;

    @NotBlank(message = "Station code is required")
    private String stationCode;

    @Min(value = 0, message = "Fare must be 0 or greater")
    private double fareTillThis;

    private LocalTime arrivalTime;
    private LocalTime departureTime;
    private int leftSeat;

    public int getLeftSeat() {
        return leftSeat;
    }

    public void setLeftSeat(int leftSeat) {
        this.leftSeat = leftSeat;
    }

    public LocalTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public LocalTime getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(LocalTime departureTime) {
        this.departureTime = departureTime;
    }

    public double getFareTillThis() {
        return fareTillThis;
    }

    public void setFareTillThis(double fareTillThis) {
        this.fareTillThis = fareTillThis;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getStationCode() {
        return stationCode;
    }

    public void setStationCode(String stationCode) {
        this.stationCode = stationCode;
    }
}
