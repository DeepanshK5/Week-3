package com.railway.user_service.controller;

import com.railway.user_service.entity.User;
import com.railway.user_service.repository.UserRepository;
import com.railway.user_service.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@Tag(name = "User Controller",description = "Login, Register And Other Endpoints Related To User Service")
public class UserController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    @Operation(summary = "Login User With Credential And Get JWT Token For Admin And User")
    public String login(@RequestBody User user){
        return userService.verify(user);
    }

    @GetMapping("/all")
    @Operation(summary = "Get All Users {Admin Only}")
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    @PostMapping("/register")
    @Operation(summary = "Register User Using Basic Details")
    public User register(@RequestBody User user){
        return userService.register(user);
    }

}
