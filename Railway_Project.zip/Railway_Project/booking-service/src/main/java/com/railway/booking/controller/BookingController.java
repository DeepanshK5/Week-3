package com.railway.booking.controller;

import com.railway.booking.entity.Booking;
import com.railway.booking.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
@Tag(name = "Booking Controller",description = "CRUD Operations Related To Booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/book")
    @Operation(summary = "Book Ticket {User}")
    public ResponseEntity<Booking> book(@Valid @RequestBody Booking booking,
                                        @RequestHeader("X-User-Email") String email) {
        return ResponseEntity.ok(bookingService.bookTicket(booking,email));
    }

    @GetMapping("/all")
    @Operation(summary = "Get All Booking {Admin Only}")
    public ResponseEntity<List<Booking>> getAllBookings(){
        return new ResponseEntity<>(bookingService.getAll(), HttpStatus.OK);
    }

    @DeleteMapping("/pnr/{pnr}")
    @Operation(summary = "Cancel Booking {User}")
    public ResponseEntity<String> cancel(@PathVariable String pnr,
                                         @RequestHeader("X-User-Email") String email) {
        bookingService.cancelTicket(pnr, email); // service handles cancellation or throws exception
        return ResponseEntity.ok("Booking cancelled for PNR: " + pnr);
    }
}
