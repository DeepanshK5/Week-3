package com.railway.booking.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    // ✅ Before method call: logs method name + class name
    @Before("execution(* com.railway.booking..*(..))")
    public void logBeforeMethod(JoinPoint joinPoint) {
        String className = joinPoint.getTarget().getClass().getSimpleName();  // e.g. StationService
        String methodName = joinPoint.getSignature().getName();               // e.g. addStation
        log.info("Starting method: {}() from class: {}", methodName, className);
    }

    // ✅ After method ends: logs method name + class name
    @After("execution(* com.railway.booking..*(..))")
    public void logAfterMethod(JoinPoint joinPoint) {
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        log.info("Finished method: {}() from class: {}", methodName, className);
    }

    // ✅ If exception occurs: logs method name + class name + error message
    @AfterThrowing(pointcut = "execution(* com.railway.booking..*(..))", throwing = "ex")
    public void logException(JoinPoint joinPoint, Throwable ex) {
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        log.error("Exception in method: {}() from class: {} | Message: {}", methodName, className, ex.getMessage());
    }
}
