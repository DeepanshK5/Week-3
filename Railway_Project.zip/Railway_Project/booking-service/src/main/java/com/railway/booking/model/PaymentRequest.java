package com.railway.booking.model;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor
public class PaymentRequest {
    private Long amount;        // amount in smallest currency unit (like paisa)
    private String currency;    // e.g., "inr"
    private String receipt;     // optional - receipt ID (can be random UUID or orderId)
    private String email;       // user email (for our DB)

    public PaymentRequest(Long amount, String currency, String receipt, String email) {
        this.amount = amount;
        this.currency = currency;
        this.receipt = receipt;
        this.email = email;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
