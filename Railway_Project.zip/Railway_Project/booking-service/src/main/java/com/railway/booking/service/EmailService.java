package com.railway.booking.service;

import com.railway.booking.entity.Booking;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

    public void sendBookingConfirmation(Booking booking, String toEmail, String paymentStatus) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8"); // true = multipart for html

            helper.setFrom("no-reply-tickets@railway.com");
            helper.setTo(toEmail);
            helper.setSubject("✅ Ticket Confirmed - PNR: " + booking.getPnr());

            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

            String html = """
            <html>
            <body style="font-family: Arial, sans-serif; background-color: #f7f9fc; padding: 20px;">
              <div style="max-width: 600px; margin: auto; background: #ffffff; border-radius: 8px; box-shadow: 0 0 10px #ccc; padding: 20px;">
                <h2 style="color: #2a9d8f;">🎟️ Booking Confirmed!</h2>
                <p>Hello <strong>%s</strong>,</p>
                <p>Thank you for booking with us. Your ticket details are below:</p>
                <table style="width: 100%%; border-collapse: collapse; margin-top: 15px;">
                  <tr style="background-color: #264653; color: white;">
                    <th style="padding: 10px; text-align: left;">Detail</th>
                    <th style="padding: 10px; text-align: left;">Information</th>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">PNR</td>
                    <td style="padding: 10px;"><strong>%s</strong></td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Train</td>
                    <td style="padding: 10px;">%s</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Date</td>
                    <td style="padding: 10px;">%s</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Route</td>
                    <td style="padding: 10px;">%s → %s</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Seats</td>
                    <td style="padding: 10px;">%d</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Total Fare</td>
                    <td style="padding: 10px;">₹ %.2f</td>
                  </tr>
                  <tr>
                    <td style="padding: 10px;">Payment Status</td>
                    <td style="padding: 10px;"><strong>%s</strong></td>
                  </tr>
                </table>
                <p style="margin-top: 20px;">Please show this email at the boarding gate.</p>
                <p style="color: #888;">Have a safe and pleasant journey!<br>— Railway Reservation System by Deepansh_5</p>
              </div>
            </body>
            </html>
        """.formatted(
                    booking.getPassengerName(),
                    booking.getPnr(),
                    booking.getTrainId(),
                    booking.getTravelDate().format(fmt),
                    booking.getSource(), booking.getDestination(),
                    booking.getSeatsBooked(),
                    booking.getFare(),
                    paymentStatus.toUpperCase()
            );

            String plainText = """
            Hello %s,

            Your ticket has been booked successfully!

            PNR: %s
            Train: %s
            Date: %s
            Route: %s → %s
            Seats: %d
            Total Fare: ₹ %.2f
            Payment Status: %s

            Please show this email at the boarding gate.

            Have a safe and pleasant journey!
            — Railway Reservation System
            """.formatted(
                    booking.getPassengerName(),
                    booking.getPnr(),
                    booking.getTrainId(),
                    booking.getTravelDate().format(fmt),
                    booking.getSource(), booking.getDestination(),
                    booking.getSeatsBooked(),
                    booking.getFare(),
                    paymentStatus.toUpperCase()
            );

            helper.setText(plainText, html);  // set both plain and html versions

            mailSender.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send booking confirmation email: " + e.getMessage(), e);
        }
    }


    public void sendBookingCancellation(Booking booking, String toEmail) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom("tickets@railwayapp.com");
            helper.setTo(toEmail);
            helper.setSubject("❌ Ticket Cancelled - PNR: " + booking.getPnr());

            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

            String html = """
            <html>
            <body style="font-family: Arial, sans-serif; background-color: #f7f9fc; padding: 20px;">
              <div style="max-width: 600px; margin: auto; background: #fff; border-radius: 8px; box-shadow: 0 0 10px #ccc; padding: 20px;">
                <h2 style="color: #e63946;">❌ Booking Cancelled</h2>
                <p>Hello <strong>%s</strong>,</p>
                <p>Your ticket has been cancelled successfully. Details are below:</p>
                <table style="width: 100%%; border-collapse: collapse; margin-top: 15px;">
                  <tr style="background-color: #d62828; color: white;">
                    <th style="padding: 10px; text-align: left;">Detail</th>
                    <th style="padding: 10px; text-align: left;">Information</th>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">PNR</td>
                    <td style="padding: 10px;"><strong>%s</strong></td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Train</td>
                    <td style="padding: 10px;">%s</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Date</td>
                    <td style="padding: 10px;">%s</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Route</td>
                    <td style="padding: 10px;">%s → %s</td>
                  </tr>
                  <tr style="border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">Seats</td>
                    <td style="padding: 10px;">%d</td>
                  </tr>
                  <tr>
                    <td style="padding: 10px;">Fare Refunded</td>
                    <td style="padding: 10px;">₹ %.2f</td>
                  </tr>
                </table>
                <p style="margin-top: 20px;">We hope to serve you again soon.</p>
                <p style="color: #888;">— Railway Reservation System by Deepansh_5</p>
              </div>
            </body>
            </html>
        """.formatted(
                    booking.getPassengerName(),
                    booking.getPnr(),
                    booking.getTrainId(),
                    booking.getTravelDate().format(fmt),
                    booking.getSource(), booking.getDestination(),
                    booking.getSeatsBooked(),
                    booking.getFare()
            );

            String plainText = """
            Hello %s,

            Your ticket has been cancelled.

            PNR: %s
            Train: %s
            Date: %s
            Route: %s → %s
            Seats: %d
            Fare Refunded: ₹ %.2f

            We hope to serve you again soon.
            — Railway Reservation System
        """.formatted(
                    booking.getPassengerName(),
                    booking.getPnr(),
                    booking.getTrainId(),
                    booking.getTravelDate().format(fmt),
                    booking.getSource(), booking.getDestination(),
                    booking.getSeatsBooked(),
                    booking.getFare()
            );

            helper.setText(plainText, html);
            mailSender.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send cancellation email: " + e.getMessage(), e);
        }
    }

}
